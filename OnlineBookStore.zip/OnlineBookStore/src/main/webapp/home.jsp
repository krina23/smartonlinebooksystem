<%-- 
    Document   : home
    Created on : 27 Mar 2026, 11:58:18 am
    Author     : patel
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("userLogin.jsp");
    }
        %>

<h2>Welcome ${user.fullname}</h2>

<a href="user?action=logout">Logout</a>
    </body>
</html>
