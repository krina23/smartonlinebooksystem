<%-- 
    Document   : userRegister
    Created on : 27 Mar 2026, 11:56:53 am
    Author     : patel
--%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
     <form action="user" method="post">
    <input type="hidden" name="action" value="register"/>

   Name: <input type="text" name="fullname" value="${fullname}" required><br>

   Email: <input type="email" name="email" value="${email}" required><br>
   
   Password: <input type="password" name="password" required><br>
   
   Phone: <input type="text" name="phone" value="${phone}" required><br>

    <button type="submit">Register</button>

    <!-- 🔴 Error Message -->
    <c:if test="${not empty error}">
    <p style="color:red;">${error}</p>
    </c:if>

    <!-- 🟢 Success Message -->
    <c:if test="${not empty success}">
    <p style="color:green;">${success}</p>
    </c:if>
</form>
    </body>
</html>
