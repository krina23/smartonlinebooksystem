<%-- 
    Document   : userLogin
    Created on : 27 Mar 2026, 11:57:25 am
    Author     : patel
--%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
       <form action="user" method="post">
    <input type="hidden" name="action" value="login"/>

    Email: <input type="text" name="email"/><br>
    Password: <input type="password" name="password"/><br>

    <button type="submit">Login</button>
</form>

${message}
    </body>
</html>
