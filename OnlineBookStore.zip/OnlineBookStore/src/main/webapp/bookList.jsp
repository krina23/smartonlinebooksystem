<%-- 
    Document   : bookList
--%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<html>
<head>
    <title>Book List</title>
</head>
<body>

<h2>📚 Book List</h2>

<!-- 🔷 SEARCH -->
<form action="books" method="get">
    <input type="hidden" name="action" value="search"/>
    <input type="text" name="keyword" placeholder="Search by title"/>
    <button type="submit">Search</button>
</form>

<br>

<!-- 🔷 ADD BOOK LINK -->
<a href="addBook.jsp">➕ Add New Book</a>

<br><br>

<!-- 🔷 TABLE -->
<table border="1" cellpadding="10">

    <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Title</th>
        <th>Description</th>
        <th>ISBN</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Pages</th>
        <th>Action</th>
    </tr>

    <c:forEach var="b" items="${bookList}">
        <tr>
            <td>${b.bookId}</td>

            <!-- 🔥 IMAGE FIX -->
            <td>
               <img src="image?name=${b.imageUrl}" width="120"/>
            </td>

            <td>${b.title}</td>

            <!-- 🔥 DESCRIPTION SAFE DISPLAY -->
            <td>
                <c:choose>
                    <c:when test="${not empty b.description}">
                        ${b.description}
                    </c:when>
                    <c:otherwise>
                        -
                    </c:otherwise>
                </c:choose>
            </td>

            <!-- 🔥 ISBN SAFE DISPLAY -->
            <td>
                <c:choose>
                    <c:when test="${not empty b.isbn}">
                        ${b.isbn}
                    </c:when>
                    <c:otherwise>
                        -
                    </c:otherwise>
                </c:choose>
            </td>

            <td>${b.price}</td>
            <td>${b.stockQuantity}</td>
            <td>${b.pages}</td>

            <!-- 🔷 ACTIONS -->
            <td>
                <a href="books?action=view&id=${b.bookId}">View</a> |
                <a href="books?action=delete&id=${b.bookId}"
                   onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
    </c:forEach>

</table>

</body>
</html>