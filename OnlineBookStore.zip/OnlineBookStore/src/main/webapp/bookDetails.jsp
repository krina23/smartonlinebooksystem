<%-- 
    Document   : bookDetails
    Created on : 27 Mar 2026, 8:31:53 pm
    Author     : patel
--%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Book Details</title>
</head>
<body>

<%
    entity.Books b = (entity.Books) request.getAttribute("book");
%>

<h2>📖 Book Details</h2>

<p><b>Title:</b> <%= b.getTitle() %></p>
<p><b>Description:</b> <%= b.getDescription() %></p>
<p><b>ISBN:</b> <%= b.getIsbn() %></p>
<p><b>Price:</b> <%= b.getPrice() %></p>
<p><b>Stock:</b> <%= b.getStockQuantity() %></p>
<p><b>Pages:</b> <%= b.getPages() %></p>

<p>
    <img src="${pageContext.request.contextPath}/${b.imageUrl}" width="120"/>
</p>

<br>
<a href="books">⬅ Back to List</a>

</body>
</html>